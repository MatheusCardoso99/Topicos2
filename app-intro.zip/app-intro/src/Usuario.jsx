import React, { useState } from 'react';
import UsuarioForm from './UsuarioForm';
import UsuarioList from './UsuarioList';
export default function Usuario() {

    let usuariosList = [
        { id: 1, nome: 'Fulano', email: 'email1@teste', celular: '54 6565 5454' },
        { id: 2, nome: 'Beltrano', email: 'email2@teste', celular: '54 6565 5454' },
    ]
    const [usuarios, setUsuarios] = useState(usuariosList)

    const onClickAtualizar = () => {
        usuariosList = [
          { id: 1, nome: 'fulano alterado', email: 'fulano@teste', celular: "3034535345" },
          { id: 2, nome: 'beltrano', email: 'beltrano@teste', idade: 20 },
          { id: 3, nome: 'ciclano', email: 'ciclano@teste', idade: 20 }
        ];
        setUsuarios(usuariosList); 
    }

    // controles para inserir salvar cancelar
    const novo = { id: null, nome: '', email: '', celular: '(54) ' }
    const [usuario, setUsuario] = useState(novo)
    const [operacao, setOperacao] = useState('listar')

    const inserir = () => {
        setUsuario(novo);
        setOperacao('inserir');
    }
    
    const salvar = () => {
        console.log('Salvar ...');

        if (operacao === 'inserir'){
            usuario.id = usuarios.length + 1
            setUsuarios([...usuarios, usuario])    
         } else if (operacao === 'editar'){
            setUsuarios(usuarios.map((find) => (find.id === usuario.id ? usuario : find)))
        }

        setOperacao('listar');
    }
    const cancelar = () => {
        console.log('Cancelou ...');
        setOperacao('listar');
    }

    const editar = (id) => {
        setUsuario(usuarios.filter((usuario) => usuario.id === id)[0]);
        setOperacao('editar');
    }

    const excluir = (id) => {
        setUsuarios(usuarios.filter((usuario) => usuario.id !== id));
    }

    if (operacao === 'inserir' || operacao === 'editar'){
        return(
            <UsuarioForm usuario={usuario} setUsuario={setUsuario} 
                         salvar={salvar} cancelar={cancelar}/>
        )

    } else 
       return (
          <UsuarioList usuarios={usuarios} onClickAtualizar={onClickAtualizar} 
                       inserir={inserir} editar={editar} excluir={excluir} />
    );
}